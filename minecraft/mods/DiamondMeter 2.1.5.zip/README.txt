This mod is for Minecraft 1.4.6 with FORGE MOD LOADER

You can download the latest version, suggest features, and get more information on the use of diamondmeter at
http://www.minecraftforum.net/topic/1337916-diamond-meter/